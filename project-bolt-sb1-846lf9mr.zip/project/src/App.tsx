import React, { useState } from 'react';
import { Brain, Shield, MessageCircle, Activity, Users, Settings, Home, BarChart3, Phone, Music, MessageSquare, Heart, Lock, CheckCircle } from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [chatMessages, setChatMessages] = useState([
    { id: 1, type: 'bot', message: "Hello! I'm here to support you. How are you feeling today?", timestamp: '2:30 PM' },
    { id: 2, type: 'user', message: "I've been feeling a bit stressed lately with work.", timestamp: '2:31 PM' },
    { id: 3, type: 'bot', message: "I understand that work stress can be challenging. Based on your recent patterns, I've noticed some changes in your communication style. Would you like to explore some stress management techniques?", timestamp: '2:32 PM' }
  ]);
  const [newMessage, setNewMessage] = useState('');

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      setChatMessages([...chatMessages, {
        id: chatMessages.length + 1,
        type: 'user',
        message: newMessage,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
      setNewMessage('');
      
      // Simulate bot response
      setTimeout(() => {
        setChatMessages(prev => [...prev, {
          id: prev.length + 1,
          type: 'bot',
          message: "Thank you for sharing. I'm analyzing your patterns and can suggest some personalized coping strategies. Would you like me to connect you with a professional therapist from our network?",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }]);
      }, 1500);
    }
  };

  const renderDashboard = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Mental Health Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-4 rounded-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100">Stress Level</p>
                <p className="text-2xl font-bold">Low</p>
              </div>
              <Activity className="w-8 h-8 text-blue-200" />
            </div>
          </div>
          <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-4 rounded-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100">Mood Score</p>
                <p className="text-2xl font-bold">7.2/10</p>
              </div>
              <Heart className="w-8 h-8 text-green-200" />
            </div>
          </div>
          <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white p-4 rounded-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100">Sleep Quality</p>
                <p className="text-2xl font-bold">Good</p>
              </div>
              <Brain className="w-8 h-8 text-purple-200" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Activity Analysis</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <MessageSquare className="w-5 h-5 text-blue-500" />
                <span className="text-sm text-gray-600">Social Media Engagement</span>
              </div>
              <span className="text-sm font-medium text-green-600">Normal</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-purple-500" />
                <span className="text-sm text-gray-600">Communication Frequency</span>
              </div>
              <span className="text-sm font-medium text-yellow-600">Decreased</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <Music className="w-5 h-5 text-pink-500" />
                <span className="text-sm text-gray-600">Music Preference</span>
              </div>
              <span className="text-sm font-medium text-green-600">Positive</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">AI Insights</h3>
          <div className="space-y-3">
            <div className="p-4 bg-blue-50 rounded-lg border-l-4 border-blue-400">
              <p className="text-sm text-blue-800">Your communication patterns show increased positivity over the past week.</p>
            </div>
            <div className="p-4 bg-yellow-50 rounded-lg border-l-4 border-yellow-400">
              <p className="text-sm text-yellow-800">Consider scheduling some social activities - your interaction frequency has decreased.</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg border-l-4 border-green-400">
              <p className="text-sm text-green-800">Your sleep pattern improvements are positively impacting your mood scores.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderChatbot = () => (
    <div className="bg-white rounded-2xl shadow-lg h-[600px] flex flex-col">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center">
          <Brain className="w-6 h-6 mr-2 text-blue-500" />
          AI Mental Health Assistant
        </h2>
        <p className="text-gray-600 mt-1">Powered by Granite AI with RAG capabilities</p>
      </div>
      
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {chatMessages.map((message) => (
          <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
              message.type === 'user' 
                ? 'bg-blue-500 text-white' 
                : 'bg-gray-100 text-gray-800'
            }`}>
              <p className="text-sm">{message.message}</p>
              <p className={`text-xs mt-1 ${message.type === 'user' ? 'text-blue-100' : 'text-gray-500'}`}>
                {message.timestamp}
              </p>
            </div>
          </div>
        ))}
      </div>
      
      <div className="p-6 border-t border-gray-200">
        <div className="flex space-x-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Type your message..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={handleSendMessage}
            className="px-6 py-2 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-colors"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );

  const renderProfessionals = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Professional Support Network</h2>
        <p className="text-gray-600 mb-6">Connect with licensed therapists and mental health professionals</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { name: 'Dr. Sarah Mitchell', specialty: 'Anxiety & Depression', rating: 4.9, available: true },
            { name: 'Dr. James Chen', specialty: 'Stress Management', rating: 4.8, available: true },
            { name: 'Dr. Emily Rodriguez', specialty: 'Cognitive Behavioral Therapy', rating: 4.9, available: false },
            { name: 'Dr. Michael Thompson', specialty: 'Trauma Counseling', rating: 4.7, available: true },
            { name: 'Dr. Lisa Park', specialty: 'Mindfulness & Meditation', rating: 4.8, available: true },
            { name: 'Dr. David Wilson', specialty: 'Relationship Counseling', rating: 4.6, available: false }
          ].map((therapist, index) => (
            <div key={index} className="bg-gray-50 rounded-xl p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold text-gray-800">{therapist.name}</h3>
                <div className={`w-3 h-3 rounded-full ${therapist.available ? 'bg-green-400' : 'bg-gray-400'}`}></div>
              </div>
              <p className="text-sm text-gray-600 mb-2">{therapist.specialty}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-yellow-600">★ {therapist.rating}</span>
                <button 
                  className={`px-3 py-1 rounded-lg text-sm ${
                    therapist.available 
                      ? 'bg-blue-500 text-white hover:bg-blue-600' 
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                  disabled={!therapist.available}
                >
                  {therapist.available ? 'Connect' : 'Unavailable'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Privacy & Security</h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
            <div className="flex items-center space-x-3">
              <Shield className="w-5 h-5 text-green-600" />
              <div>
                <p className="font-medium text-green-800">End-to-End Encryption</p>
                <p className="text-sm text-green-600">All your data is encrypted and secure</p>
              </div>
            </div>
            <CheckCircle className="w-6 h-6 text-green-600" />
          </div>
          
          <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center space-x-3">
              <Lock className="w-5 h-5 text-blue-600" />
              <div>
                <p className="font-medium text-blue-800">Data Privacy</p>
                <p className="text-sm text-blue-600">No third-party access to your personal information</p>
              </div>
            </div>
            <CheckCircle className="w-6 h-6 text-blue-600" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Connected Platforms</h3>
        <div className="space-y-3">
          {[
            { platform: 'Social Media Monitoring', status: 'Connected', icon: MessageSquare },
            { platform: 'Communication Analysis', status: 'Connected', icon: MessageCircle },
            { platform: 'Music Preference Tracking', status: 'Connected', icon: Music },
            { platform: 'Call Pattern Analysis', status: 'Connected', icon: Phone }
          ].map((item, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <item.icon className="w-5 h-5 text-gray-600" />
                <span className="text-gray-700">{item.platform}</span>
              </div>
              <span className="text-sm text-green-600 font-medium">{item.status}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-500 p-2 rounded-lg">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-800">MindCare AI</h1>
            </div>
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1 text-sm text-green-600">
                <Shield className="w-4 h-4" />
                <span>Encrypted</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <nav className="bg-white rounded-2xl shadow-lg p-4">
              <div className="space-y-2">
                {[
                  { id: 'dashboard', label: 'Dashboard', icon: Home },
                  { id: 'chatbot', label: 'AI Assistant', icon: MessageCircle },
                  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
                  { id: 'professionals', label: 'Professionals', icon: Users },
                  { id: 'settings', label: 'Settings', icon: Settings }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${
                      activeTab === item.id
                        ? 'bg-blue-500 text-white shadow-lg'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    <span className="font-medium">{item.label}</span>
                  </button>
                ))}
              </div>
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'dashboard' && renderDashboard()}
            {activeTab === 'chatbot' && renderChatbot()}
            {activeTab === 'professionals' && renderProfessionals()}
            {activeTab === 'settings' && renderSettings()}
            {activeTab === 'analytics' && (
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-4">Analytics Dashboard</h2>
                <p className="text-gray-600">Detailed analytics and insights coming soon...</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;